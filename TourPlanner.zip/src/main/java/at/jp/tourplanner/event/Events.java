package at.jp.tourplanner.event;

public enum Events {

    TOURS_CHANGED,
    TOUR_SELECTED,
    TOURLOG_SELECTED,
    TOURLOGS_CHANGED,
    TOURS_EDITED
}
