package at.jp.tourplanner.viewmodel.tour;

import at.jp.tourplanner.dto.Geocode;
import at.jp.tourplanner.event.EventManager;
import at.jp.tourplanner.event.Events;
import at.jp.tourplanner.service.TourService;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.collections.FXCollections;
import javafx.scene.web.WebEngine;

import java.util.List;

public class TourMapViewModel {

    private final TourService tourService;
    private final EventManager eventManager;
    private WebEngine webEngine;

    public TourMapViewModel(EventManager eventManager, TourService tourService) {
        this.eventManager = eventManager;
        this.tourService = tourService;
        this.eventManager.subscribe(Events.TOUR_SELECTED, this::onTourSelected);
    }

    private void onTourSelected(Boolean deselected) {
        String clearScript = """
              map.eachLayer(function(layer) {
                    if (!!layer.toGeoJSON) {
                        map.removeLayer(layer);
                    }
                });
                map.setView([51.505, -0.09], 13);
              """;
        webEngine.executeScript(clearScript);

        if(!deselected) {
            StringBuilder scriptBuilder = new StringBuilder("var latlngs = [");
            for (Geocode g : tourService.getRouteGeocodes()) {
                scriptBuilder.append(String.format(java.util.Locale.ENGLISH, "[%f, %f],", g.getLatitude(), g.getLongitude()));
            }
            scriptBuilder.setLength(scriptBuilder.length() - 1);
            scriptBuilder.append("]; var polyline = L.polyline(latlngs, {color: 'blue'}).addTo(map); map.fitBounds(polyline.getBounds());");
            webEngine.executeScript(scriptBuilder.toString());
        }
    }

    public void setWebEngine(WebEngine webEngine) {
        this.webEngine = webEngine;
    }
    public void init() {
        String html = getClass().getResource("/at/jp/tourplanner/map.html").toExternalForm();
        this.webEngine.load(html);
    }
}
