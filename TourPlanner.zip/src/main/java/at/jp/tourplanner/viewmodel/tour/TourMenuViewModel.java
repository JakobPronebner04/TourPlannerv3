package at.jp.tourplanner.viewmodel.tour;


import at.jp.tourplanner.event.EventManager;
import at.jp.tourplanner.event.Events;
import at.jp.tourplanner.inputmodel.Tour;
import at.jp.tourplanner.service.TourService;
import at.jp.tourplanner.window.WindowManager;
import at.jp.tourplanner.window.Windows;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class TourMenuViewModel {

    private final TourService tourService;
    private final WindowManager windowManager;
    private final EventManager eventManager;
    private final BooleanProperty editDisabled = new SimpleBooleanProperty(true);
    private final BooleanProperty removeDisabled = new SimpleBooleanProperty(true);
    private final BooleanProperty detailsDisabled = new SimpleBooleanProperty(true);

    public TourMenuViewModel(EventManager eventManager, TourService tourService, WindowManager windowManager) {
        this.tourService = tourService;
        this.windowManager = windowManager;
        this.eventManager = eventManager;
        this.eventManager.subscribe(
                Events.TOUR_SELECTED, this::onTourSelectedChanged
        );
    }

    public void onTourSelectedChanged(Boolean state) {
        editDisabled.set(state);
        removeDisabled.set(state);
        detailsDisabled.set(state);
    }

    public void openNewTourWindow(){
            windowManager.openWindow(Windows.NEW_TOUR_WINDOW);
    }
    public void openEditTourWindow(){
        windowManager.openWindow(Windows.EDIT_TOUR_WINDOW);
    }
    public void openDetailsTourWindow(){
        windowManager.openWindow(Windows.DETAILS_TOUR_WINDOW);
    }
    public BooleanProperty editDisabledProperty() {
        return editDisabled;
    }
    public BooleanProperty removeDisabledProperty() {
        return removeDisabled;
    }
    public BooleanProperty detailsDisabledProperty() { return detailsDisabled;}
    public void deleteTour()
    {
        tourService.remove();
    }
}
