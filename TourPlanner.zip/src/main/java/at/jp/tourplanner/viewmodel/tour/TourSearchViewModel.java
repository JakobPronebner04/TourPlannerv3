package at.jp.tourplanner.viewmodel.tour;

import at.jp.tourplanner.event.EventManager;
import at.jp.tourplanner.event.Events;
import at.jp.tourplanner.service.TourService;
import at.jp.tourplanner.window.WindowManager;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class TourSearchViewModel {
    private final TourService tourService;
    private final StringProperty searchText = new SimpleStringProperty("");

    public TourSearchViewModel(TourService tourService) {
        this.tourService = tourService;
        this.searchText.addListener(this::onTourSearchTextChanged);
    }
    public StringProperty searchTextProperty() {
        return searchText;
    }

    private void onTourSearchTextChanged(Observable observable, String oldSearchText, String newSearchText) {
        if(oldSearchText.equals(newSearchText))
        {
            return;
        }
        tourService.updateSearchText(newSearchText);
    }
}
