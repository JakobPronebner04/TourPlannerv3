package at.jp.tourplanner.dataaccess;

import at.jp.tourplanner.inputmodel.Tour;
import at.jp.tourplanner.inputmodel.TourLog;

public class StateDataAccess {
    private TourLog selectedTourLog;
    private Tour selectedTour;
    private String searchText;

    public StateDataAccess() {
        searchText = "";
    }
    public TourLog getSelectedTourLog() {
        return selectedTourLog;
    }
    public Tour getSelectedTour() {
        return selectedTour;
    }
    public String getSearchText() {
        return searchText;
    }

    public void updateSelectedTour(Tour newSelectedTour)
    {
        selectedTour = newSelectedTour;
    }
    public void updateSelectedTourLog(TourLog newSelectedTourLog)
    {
        selectedTourLog = newSelectedTourLog;
    }
    public void updateSearchText(String searchText)
    {
        this.searchText = searchText;
    }
}
