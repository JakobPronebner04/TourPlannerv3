package at.jp.tourplanner.window;

public enum Windows {
    NEW_TOUR_WINDOW,
    EDIT_TOUR_WINDOW,
    NEW_TOURLOG_WINDOW,
    EDIT_TOURLOG_WINDOW,
    DETAILS_TOUR_WINDOW,
    DETAILS_TOURLOG_WINDOW
}
