package at.jp.tourplanner.service.openrouteservice;

public class DirectionsSummary {
    private float distance;
    private float duration;

    public float getDistance() {
        return distance;
    }
    public void setDistance(float distance) {
        this.distance = distance;
    }
    public float getDuration() {
        return duration;
    }

    public void setDuration(float duration) {
        this.duration = duration;
    }
}
