package at.jp.tourplanner.service.openrouteservice;

public class DirectionsProperties {
    private DirectionsSummary summary;
    public DirectionsSummary getSummary() {
        return summary;
    }
    public void setSummary(DirectionsSummary summary) {
        this.summary = summary;
    }
}
