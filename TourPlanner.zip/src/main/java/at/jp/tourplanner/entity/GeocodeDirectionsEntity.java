package at.jp.tourplanner.entity;

import jakarta.persistence.*;

import java.util.UUID;

@Entity
public class GeocodeDirectionsEntity {
    @Id
    @GeneratedValue
    private UUID id;
    @Lob
    @Column(columnDefinition = "TEXT")
    private String jsonDirections;
    private float tourDistance;
    private float tourDuration;

    @OneToOne
    @JoinColumn(name = "tour_id")
    private TourEntity tour;

    public UUID getId() {
        return id;
    }

    public String getJsonDirections() {
        return jsonDirections;
    }

    public void setJsonDirections(String jsonDirections) {
        this.jsonDirections = jsonDirections;
    }

    public float getDistance() {
        return tourDistance;
    }
    public void setDistance(float tourDistance) {
        this.tourDistance = tourDistance;
    }
    public float getDuration() {
        return tourDuration;
    }
    public void setDuration(float tourDuration) {
        this.tourDuration = tourDuration;
    }

    public TourEntity getTour() {
        return tour;
    }

    public void setTour(TourEntity tour) {
        this.tour = tour;
    }
}