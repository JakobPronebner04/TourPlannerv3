# Tour Planner
Form a team of two students to develop an application based on the GUI frameworks Java / JavaFX.
The user creates (bike-, hike-, running- or vacation-) tours in advance and manages the logs and statistical data of accomplished tours.
